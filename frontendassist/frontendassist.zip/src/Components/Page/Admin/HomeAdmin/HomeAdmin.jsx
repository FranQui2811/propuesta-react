import React, { useState } from 'react';
import './HomeAdmin.css';

export const HomeAdmin = () => {
    const [activeModule, setActiveModule] = useState(null);

    // Módulos de administración
    const modules = [
        { id: 'users', title: 'Gestión de Usuarios', icon: '👥' },
        { id: 'subjects', title: 'Gestión de Materias', icon: '📚' },
        { id: 'teachers', title: 'Gestión de Profesores', icon: '👨‍🏫' },
        { id: 'classes', title: 'Gestión de Clases', icon: '🏫' },
    ];

    const renderModuleContent = () => {
        switch (activeModule) {
            case 'users':
                return <div className="module-content">
                    <h2>Gestión de Usuarios</h2>
                    {/* Aquí irá el componente de gestión de usuarios */}
                </div>;
            case 'subjects':
                return <div className="module-content">
                    <h2>Gestión de Materias</h2>
                    {/* Aquí irá el componente de gestión de materias */}
                </div>;
            case 'teachers':
                return <div className="module-content">
                    <h2>Gestión de Profesores</h2>
                    {/* Aquí irá el componente de gestión de profesores */}
                </div>;
            case 'classes':
                return <div className="module-content">
                    <h2>Gestión de Clases</h2>
                    {/* Aquí irá el componente de gestión de clases */}
                </div>;
            default:
                return <div className="welcome-message">
                    <h2>Bienvenido al Panel de Administración</h2>
                    <p>Seleccione un módulo para comenzar</p>
                </div>;
        }
    };

    return (
        <div className="admin-container">
            <div className="admin-sidebar">
                <h1>Panel Admin</h1>
                <div className="module-buttons">
                    {modules.map((module) => (
                        <button
                            key={module.id}
                            className={`module-button ${activeModule === module.id ? 'active' : ''}`}
                            onClick={() => setActiveModule(module.id)}
                        >
                            <span className="module-icon">{module.icon}</span>
                            {module.title}
                        </button>
                    ))}
                </div>
            </div>
            <div className="admin-content">
                {renderModuleContent()}
            </div>
        </div>
    );
};

export default HomeAdmin;